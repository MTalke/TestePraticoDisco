﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TestePraticoDisco
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var escolha = "S";
            int quantidade_albuns = 0;

            while (escolha != "N") 
            { 
                Console.WriteLine("Escolha uma das opções a seguir");
                Console.WriteLine("Digite 1 para adicionar um album");
                Console.WriteLine("Digite 2 para sair");
                int opcao = int.Parse(Console.ReadLine());
                Console.WriteLine($"você escolheu a opção, {opcao}.");
                if(opcao == 1) {
                    Console.WriteLine($"Quantos albuns deseja adicionar?");
                    quantidade_albuns = int.Parse(Console.ReadLine());  
                
                    Album[]	albuns =  new Album[quantidade_albuns];

                    
                    adicionarAlbum(quantidade_albuns, albuns);                 
                    if(albuns.Count() >= 1){
                        Console.WriteLine($"Deseja buscar algum album?");
                        Console.WriteLine($"se sim digite S");
                        var pesquisar = Console.ReadLine();
                        if(pesquisar == "S") {
                            Console.WriteLine($"Escolha o tipo de busca");
                            Console.WriteLine($"(1) Por título");
                            Console.WriteLine($"(2) Por Músicas");
                            Console.WriteLine($"(3) Por Nome da Banda ou Artista");
                            int tipo_busca = int.Parse(Console.ReadLine());  
                            Console.WriteLine($"Pesquisar (" + tipo_busca + ")");
                            var buscar = Console.ReadLine();
                            pesquisarAlbum(tipo_busca, buscar, albuns);
                        }
                        Console.WriteLine($"Deseja gerar uma playlist?");
                        Console.WriteLine($"se sim digite S");
                        var resposta_playlist = Console.ReadLine();
                        if(pesquisar == "S") {
                            gerarPlaylist(albuns);   
                        }                     

                    } else {
                        Console.WriteLine($"Ainda não foi criado nenhum album para poder pesquisar");
                    }  
                }

                Console.WriteLine($"Deseja voltar para o menu digite S se não digite N");
                escolha = Console.ReadLine();
            }


        }

        public static void gerarPlaylist(Album[] albuns)
        {
                Random randNum = new Random();
                int aleatorio;
                int total_musicas;
                int total_musicas_favoritas;

                Console.WriteLine($"Playlist");         
                for (int i = 0; i < albuns.Length; i++) {
                        total_musicas = (albuns[i].quantidade_musicas()/2);
                        for (int j = 0; j < total_musicas; j++) { 
                                aleatorio = randNum.Next(albuns[i].quantidade_musicas());
                                if(albuns[i].todas_as_musicas()[j].getFavorita() != true)
                                Console.WriteLine(" - " + albuns[i].todas_as_musicas()[aleatorio].getNomeMusica()); 
                    }                                                                
                }

                for (int i = 0; i < albuns.Length; i++) { 
                        total_musicas_favoritas = (albuns[i].quantidade_musicas()/2);
                        for (int j = 0; j < total_musicas_favoritas; j++) { 
                                if(albuns[i].todas_as_musicas()[j].getFavorita() == true)
                                Console.WriteLine(" - " + albuns[i].todas_as_musicas()[j].getNomeMusica()); 
                    }                                                                
                } 

        }


        public static Album[] adicionarAlbum(int quantidade_albuns, Album[] albuns)
        {
                for (int i = 0; i < quantidade_albuns; i++) { 
                                
                    albuns[i] =  new Album();
                    int numeracao_album = i + 1;

                    Console.WriteLine($"Opção 1 - Adicionar albuns");

                    Console.WriteLine("Escreva o nome do album " + numeracao_album);
                    var titulo = Console.ReadLine();
                    albuns[i].setTitulo(titulo);
                    Console.WriteLine("Escreva o ano do album " + numeracao_album);
                    var ano = Console.ReadLine();                    
                    albuns[i].setAno(Int32.Parse(ano));
                    Console.WriteLine("Escreva o nome da banda ou artista do album " + numeracao_album);
                    var nome_banda = Console.ReadLine();
                    albuns[i].setNomeBanda(nome_banda);

                    Console.WriteLine($"Quantas músicas tem esse album?");
                    int quantidade_musicas = int.Parse(Console.ReadLine());
                    adicionarMusicas(quantidade_musicas, albuns[i]);                             
                } 

                return albuns;
        }

        public static int pesquisarAlbum(int tipo, string buscar, Album[] albuns)
        {
              // Pesquisar por Título
              if(tipo == 1){
                    Console.WriteLine($"Opção 1 " + buscar); 
                    for (int i = 0; i < albuns.Length; i++) { 
                        if(albuns[i].getTitulo() == buscar) {
                            Console.WriteLine("------Achou------");
                            Console.WriteLine("Ano do album: " + albuns[i].getAno());
                            Console.WriteLine("Nome da banda ou artista: " + albuns[i].getNomeBanda());
                            Console.WriteLine("Músicas");
                            for (int j = 0; j < albuns[i].quantidade_musicas(); j++) { 
                            Console.WriteLine(" - " + albuns[i].todas_as_musicas()[j].getNomeMusica()); 
                            Console.WriteLine(" Duração: " + albuns[i].todas_as_musicas()[j].getDuracao());
                            if(albuns[i].todas_as_musicas()[j].getFavorita() == true) 
                            Console.WriteLine(" Favorita"); 
                            }                              
                        }                                                                
                    }
                    return 1;         
              // Pesquisar por Músicas      
              } else if(tipo == 2){
                    Console.WriteLine($"Opção 2 " + buscar);         
                    for (int i = 0; i < albuns.Length; i++) { 
                            for (int j = 0; j < albuns[i].quantidade_musicas(); j++) { 
                                if(albuns[i].todas_as_musicas()[j].getNomeMusica() == buscar) {
                                    Console.WriteLine(" Duração: " + albuns[i].todas_as_musicas()[j].getDuracao());
                                    Console.WriteLine("Nome do album: " + albuns[i].getTitulo());
                                    Console.WriteLine("Ano do album: " + albuns[i].getAno());
                                    Console.WriteLine("Nome da banda ou artista " + albuns[i].getNomeBanda());
                                }                            
                        }                                                                
                    }                                
                    return 2;
              // Pesquisar por Nome da Banda
              } else {
                    Console.WriteLine($"Opção 3 " + buscar);  
                    for (int i = 0; i < albuns.Length; i++) { 
                        if(albuns[i].getNomeBanda() == buscar) {
                            Console.WriteLine("------Achou------");
                            Console.WriteLine("Nome do album: " + albuns[i].getTitulo());
                            Console.WriteLine("Ano do album: " + albuns[i].getAno());
                            Console.WriteLine("Músicas");
                            for (int j = 0; j < albuns[i].quantidade_musicas(); j++) { 
                            Console.WriteLine(" - " + albuns[i].todas_as_musicas()[j].getNomeMusica()); 
                            Console.WriteLine(" Duração: " + albuns[i].todas_as_musicas()[j].getDuracao()); 
                            if(albuns[i].todas_as_musicas()[j].getFavorita() == true) 
                            Console.WriteLine(" Favorita"); 
                            }    
                        }                                                                
                    }                                       
                     return 3;
              }
        }

        public static void adicionarMusicas(int quantidade_musicas, Album album)
        {            
            Musica musica;
            bool favorita;

            for (int i = 0; i < quantidade_musicas; i++) { 
                int numeracao_musica = i + 1;
                Console.WriteLine("Escreva o nome da música " + numeracao_musica);
                var nome_musica = Console.ReadLine();
                Console.WriteLine("Duração da música em minutos " + numeracao_musica);
                double duracao = Convert.ToDouble(Console.ReadLine());  
                Console.WriteLine("Adicionar esta música como favorita? digite (S)");    
                var resposta_musica_favorita = Console.ReadLine();
                if(resposta_musica_favorita == "S") {
                    favorita = true;
                } else {
                    favorita = false;
                }
                musica = new Musica(favorita, duracao, nome_musica);
                album.setMusica(musica);
            }   

        }
    }
}