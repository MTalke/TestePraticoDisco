using System.Collections.Generic;

public class Album
{
       private string titulo;
       private int ano;
       private string nome_banda;
       private List<Musica> musicas = new List<Musica>();


       public Album()
       {
              this.nome_banda = " ";
              this.ano = 0;
              this.titulo = " ";              
       }

       public Album(string nome_banda, int ano, string titulo)
       {
              this.nome_banda = nome_banda;
              this.ano = ano;
              this.titulo = titulo;
       }
 
       public void setNomeBanda(string nome_banda)
       {
              this.nome_banda = nome_banda;
       }

       public string getNomeBanda()
       {
              return this.nome_banda;
       }

       public void setAno(int ano)
       {
              this.ano = ano;
       }

       public int getAno()
       {
              return this.ano;
       }

       public void setTitulo(string titulo)
       {
              this.titulo = titulo;
       }

       public string getTitulo()
       {
              return this.titulo;
       }

       public void setMusica(Musica musica)
       {
              this.musicas.Add(musica);
       }

       public Musica getMusica(int id)
       {
              return this.musicas[id];
       }

       public int quantidade_musicas()
       {              
              return this.musicas.Count;
       }

       public List<Musica> todas_as_musicas()
       {
              return this.musicas;
       }
}