public class Musica : Album
{
       private string nome_musica;
       private double duracao;
       private bool favorita;

       public Musica()
       {
              this.favorita = false;
              this.duracao = 0;
              this.nome_musica = " ";
       }

       public Musica(bool favorita, double duracao, string nome_musica)
       {
              this.favorita = favorita;
              this.duracao = duracao;
              this.nome_musica = nome_musica;
       }
 
       public void setFavorita(bool favorita)
       {
              this.favorita = favorita;
       }

       public bool getFavorita()
       {
              return this.favorita;
       }

       public void setDuracao(double duracao)
       {
              this.duracao = duracao;
       }

       public double getDuracao()
       {
              return this.duracao;
       }

       public void setNomeMusica(string nome_musica)
       {
              this.nome_musica = nome_musica;
       }

       public string getNomeMusica()
       {
              return this.nome_musica;
       }

}